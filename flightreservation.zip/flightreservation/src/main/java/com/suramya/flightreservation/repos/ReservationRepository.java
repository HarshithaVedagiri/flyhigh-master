package com.suramya.flightreservation.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.suramya.flightreservation.entities.Reservation;


public interface ReservationRepository extends JpaRepository<Reservation, Long> {

}
